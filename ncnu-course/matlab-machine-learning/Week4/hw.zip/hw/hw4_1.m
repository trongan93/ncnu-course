inputX = [10 20 30];
y = fun1001(inputX);
disp(y)

inputA = [1 2 3 4];
inputB = [5 6 7 8];
y2 = fun1002(inputA,inputB);
disp(y2);

inputX = [1 2 3];
m = 5;
y3 = fun1003(inputX,m);
