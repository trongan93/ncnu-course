function y = fun1002(a,b)
    y = (2./(abs(a)+1)).^(b-1);
end