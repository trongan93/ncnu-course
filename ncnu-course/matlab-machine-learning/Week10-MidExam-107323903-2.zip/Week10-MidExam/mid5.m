% Test function 1
y = fun01([2, 3, 4 ,5], 3);

% Test function 2
y2 = fun02([2,3,4,5]);